﻿#pragma once

// Name: mace, Version: 1.9.1.12285


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ABP_Character_1P_New.ABP_Character_1P_New_C.AnimGraph
struct UABP_Character_1P_New_C_AnimGraph_Params
{
	struct FPoseLink                                   AnimGraph;                                                 // (Parm, OutParm, NoDestructor)
};

// Function ABP_Character_1P_New.ABP_Character_1P_New_C.BlueprintUpdateAnimation
struct UABP_Character_1P_New_C_BlueprintUpdateAnimation_Params
{
	float                                              DeltaTimeX;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ABP_Character_1P_New.ABP_Character_1P_New_C.BlueprintInitializeAnimation
struct UABP_Character_1P_New_C_BlueprintInitializeAnimation_Params
{
};

// Function ABP_Character_1P_New.ABP_Character_1P_New_C.AnimNotify_OnFootStep
struct UABP_Character_1P_New_C_AnimNotify_OnFootStep_Params
{
};

// Function ABP_Character_1P_New.ABP_Character_1P_New_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Character_1P_New_AnimGraphNode_LayeredBoneBlend_3AC5DAFD4835633CC92B60B7160B9272
struct UABP_Character_1P_New_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Character_1P_New_AnimGraphNode_LayeredBoneBlend_3AC5DAFD4835633CC92B60B7160B9272_Params
{
};

// Function ABP_Character_1P_New.ABP_Character_1P_New_C.AnimNotify_OnGrabAmmo
struct UABP_Character_1P_New_C_AnimNotify_OnGrabAmmo_Params
{
};

// Function ABP_Character_1P_New.ABP_Character_1P_New_C.AnimNotify_OnReleaseAmmo
struct UABP_Character_1P_New_C_AnimNotify_OnReleaseAmmo_Params
{
};

// Function ABP_Character_1P_New.ABP_Character_1P_New_C.Play Debug Montage 1
struct UABP_Character_1P_New_C_Play_Debug_Montage_1_Params
{
};

// Function ABP_Character_1P_New.ABP_Character_1P_New_C.ExecuteUbergraph_ABP_Character_1P_New
struct UABP_Character_1P_New_C_ExecuteUbergraph_ABP_Character_1P_New_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
