﻿#pragma once

// Name: mace, Version: 1.9.1.12285


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BP_CTFGameMode.BP_CTFGameMode_C.ReceiveBeginPlay
struct ABP_CTFGameMode_C_ReceiveBeginPlay_Params
{
};

// Function BP_CTFGameMode.BP_CTFGameMode_C.ExecuteUbergraph_BP_CTFGameMode
struct ABP_CTFGameMode_C_ExecuteUbergraph_BP_CTFGameMode_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
