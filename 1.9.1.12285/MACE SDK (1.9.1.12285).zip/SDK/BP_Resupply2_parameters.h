﻿#pragma once

// Name: mace, Version: 1.9.1.12285


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BP_Resupply2.BP_Resupply2_C.OnGivenTo
struct UBP_Resupply2_C_OnGivenTo_Params
{
};

// Function BP_Resupply2.BP_Resupply2_C.OnRemoved
struct UBP_Resupply2_C_OnRemoved_Params
{
};

// Function BP_Resupply2.BP_Resupply2_C.ExecuteUbergraph_BP_Resupply2
struct UBP_Resupply2_C_ExecuteUbergraph_BP_Resupply2_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
