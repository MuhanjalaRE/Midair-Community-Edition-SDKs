﻿#pragma once

// Name: mace, Version: 1.9.1.12285


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function ABP_Chaingun_New.ABP_Chaingun_New_C.AnimGraph
struct UABP_Chaingun_New_C_AnimGraph_Params
{
	struct FPoseLink                                   AnimGraph;                                                 // (Parm, OutParm, NoDestructor)
};

// Function ABP_Chaingun_New.ABP_Chaingun_New_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Chaingun_New_AnimGraphNode_ModifyBone_7BDCEE37452BA7E7FE24D8854DF3B788
struct UABP_Chaingun_New_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Chaingun_New_AnimGraphNode_ModifyBone_7BDCEE37452BA7E7FE24D8854DF3B788_Params
{
};

// Function ABP_Chaingun_New.ABP_Chaingun_New_C.BlueprintUpdateAnimation
struct UABP_Chaingun_New_C_BlueprintUpdateAnimation_Params
{
	float                                              DeltaTimeX;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function ABP_Chaingun_New.ABP_Chaingun_New_C.BlueprintInitializeAnimation
struct UABP_Chaingun_New_C_BlueprintInitializeAnimation_Params
{
};

// Function ABP_Chaingun_New.ABP_Chaingun_New_C.ExecuteUbergraph_ABP_Chaingun_New
struct UABP_Chaingun_New_C_ExecuteUbergraph_ABP_Chaingun_New_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
