﻿#pragma once

// Name: mace, Version: 1.9.1.12285


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BP_LightCharacter_Bot.BP_LightCharacter_Bot_C.ReceiveTick
struct ABP_LightCharacter_Bot_C_ReceiveTick_Params
{
	float                                              DeltaSeconds;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function BP_LightCharacter_Bot.BP_LightCharacter_Bot_C.ReceiveBeginPlay
struct ABP_LightCharacter_Bot_C_ReceiveBeginPlay_Params
{
};

// Function BP_LightCharacter_Bot.BP_LightCharacter_Bot_C.BP_UpdateForClientPerspective
struct ABP_LightCharacter_Bot_C_BP_UpdateForClientPerspective_Params
{
	bool                                               bFirstPerson;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// Function BP_LightCharacter_Bot.BP_LightCharacter_Bot_C.ExecuteUbergraph_BP_LightCharacter_Bot
struct ABP_LightCharacter_Bot_C_ExecuteUbergraph_BP_LightCharacter_Bot_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
