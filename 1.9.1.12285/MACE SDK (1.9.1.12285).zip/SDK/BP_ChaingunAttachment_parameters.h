﻿#pragma once

// Name: mace, Version: 1.9.1.12285


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function BP_ChaingunAttachment.BP_ChaingunAttachment_C.ReceiveBeginPlay
struct ABP_ChaingunAttachment_C_ReceiveBeginPlay_Params
{
};

// Function BP_ChaingunAttachment.BP_ChaingunAttachment_C.ReceiveTick
struct ABP_ChaingunAttachment_C_ReceiveTick_Params
{
	float                                              DeltaSeconds;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function BP_ChaingunAttachment.BP_ChaingunAttachment_C.ExecuteUbergraph_BP_ChaingunAttachment
struct ABP_ChaingunAttachment_C_ExecuteUbergraph_BP_ChaingunAttachment_Params
{
	int                                                EntryPoint;                                                // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
